Hello I am Haoqin Wei
This is my ics 32 assignment1 part1